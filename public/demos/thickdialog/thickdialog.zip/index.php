<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Thickdialog</title>
        
        <!-- JQUERY -->
        <script type="text/javascript" src="jquery-1.7.2.min"></script>
        
        <!-- JQUERY UI -->
        <script type="text/javascript" src="jquery-ui-1.8.21.custom.min.js"></script>
        <link href="jquery-ui-1.8.21.custom.css" media="screen" rel="stylesheet" type="text/css" >
        
        <!--thickdialog -->
        <script type="text/javascript" src="thickdialog.js"></script>

	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />

	
</head>
<body>
        <style type="text/css">
            h1,h2 {font-size:12px;}
            #dialog {font-size:10px;}
        </style>        
	<h1>ThickDialog examples</h1>
        <a href="thickdialog.zip" target="_BLANK">Download</a>
        
        <h2>Simple thickbox style popup</h2>
        <p>
            <a href="popup.html" title="A pop up" class="dialog-box">Popup example</a>
            code: <pre>&lt;a href="popup.html" title="A pop up" class="dialog-box">Popup example&lt;/a&gt;</pre>
            usage: add the class "dialog-box" to make this work
        </p>
        
        <h2>Simple thickbox style confirmation box</h2>
        <p>
            <a href="delete.html" title="Are you sure?" class="dialog-confirm">Confirm example</a>
            code: <pre>&lt;a href="delete.html" title="Are you sure?" class="dialog-confirm">Confirm example&lt;/a&gt;</pre>
            usage: add the class "dialog-confirm" to make this work
        </p>
        
        <h2>Simple thickbox style form submission</h2>
        <p>
            <a href="form.php" title="Please complete" class="dialog-form">Form example</a>
            code: <pre>&lt;a href="form.php" title="Please complete" class="dialog-confirm">Form example&lt;/a&gt;</pre>
            usage: add the class "dialog-form" to make this work
        </p>
        
</body>
</html>
