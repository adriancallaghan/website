<?php

require_once('classes.php'); // load the classes




Output::toCsv(
        database::getInstance()->setConfig(
            database::stdConfig(array('password'=>'1234'))
            )->fetchAll()
        );
   


//echo database::getInstance()->error;

