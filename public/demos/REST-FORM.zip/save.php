<?php

require_once('classes.php'); // load the classes




Output::toXml(
        listener::getInstance()
                ->setFields(
                        array(
                            'bob'=>true
                            )
                        )
                ->setAction(
                    database::getInstance()->setConfig(
                        database::stdConfig(
                                array(
                                    'password'=>'1234'
                                    )
                                )
                    )
                )
            );
   


//foreach(listener::getInstance()->errors AS $err) echo $err;




