<?php



class listener{
  
    private static $m_pInstance;

    protected $_action;
    protected $_method;
    protected $_fields;
    protected $_success;
    protected $_errors;
    protected $_input;
    
    private function __construct(){}

    
    public function __set($name, $value)
    {
        $method = 'set' . $name;        
        if (method_exists($this, $method)){
            return $this->$method($value);
        }
                
        throw new Exception('Invalid Listener property');
    }

    public function __get($name)
    {
        
        $method = 'get' . $name;        
        if (method_exists($this, $method)){
            return $this->$method();
        }

        throw new Exception('Invalid Listener property '.$method);

    }
    

    public function setMethod($method='GET'){
        
        $this->_method = $method;
        return $this;
        
    }
    public function getMethod(){
        
        if (!isset($this->_method)){
            $this->setMethod();
        }
        return $this->_method;
        
    }
        
    public function setFields(array $fields = array()){
        
        $this->_fields = $fields;
        return $this;
    
    }
    
    public function getFields(){
        
        if (!isset($this->_fields)){
            $this->setFields();
        }
        return $this->_fields;
        
    }
    
    public function getInput(){
        
        if (!isset($this->_input)){
            $this->setInput();
        }
        
        return $this->_input;
    }
    
    public function setInput(array $input = null){
        
        if ($input === null){
            switch (strtolower($this->method)){
                case 'get': $input = isset($_GET) ? $_GET : null; break;
                default: $input = isset($_POST) ? $_POST : null; break;
            }
        }
        $this->_input = $input;
        return $this;
        
    }
    
    public function getErrors(){
        
        if (!isset($this->_errors)){
            $this->setErrors();
        }
        return $this->_errors;
    }
    
    public function setErrors(array $errors = null){
        
        if ($errors===null){
            $errors = array();
        }
        
        $this->_errors = $errors;
        return $this;
    }
    
    
    public function addError($error){ 
    
        $errors = $this->errors;
        $errors[] = $error;
        $this->errors = $errors;
        return $this;
    }
    
    public function execute(){
        
        if (!$input = $this->input){
            $this->addError('no submission for method : '.$this->method);
            $this->success = false;
            return array();
        }
        
        $output = array();
        foreach ($this->fields AS $fieldName=>$required){
            
            if ($required && !isset($input[$fieldName]) || $input[$fieldName]==''){
                $this->addError("Field $fieldName is a required field");
                $this->success = false;
            } else {
                $output[$fieldName] = $input[$fieldName];
            } 
        }

        return $output;
        
    }
    
    public function getSuccess(){
        
        if (!isset($this->_success)){
            $this->setSuccess();
        }
        return $this->_success;
        
    }
    
    public function setSuccess($success = true){
        
        $this->_success = $success;
        return $this;
    }
    
    public function setAction($action = null){
        
        if ($action===null){  
            $this->_action = new Screen();
        } else {
            $this->_action = $action;
        }
        
        return $this;
    }
    
    public function getAction(){
        
        if (!isset($this->_action)){
            $this->setAction();
        }
        
        return $this->_action;
    }
    
    // static methods
    public static function getInstance()
    {
        
        if (!self::$m_pInstance){
            self::$m_pInstance = new listener();
        }

        return self::$m_pInstance;
    }
    
    // reports success
    public function __toString() {
        
        $this->action->execute($this);
        
        return $this->success ? '1' : '0';
    }
    
}



class Screen {

    public function execute(listener $listener){

        $values = $listener->execute();
        if ($listener->success){
            
            // test error
            if (1==0){
                $listener->addError('Test error');
                $listener->success = false;
                return;
            }
            
            echo 'Dump<pre>';
            print_r($values);
            echo '</pre>';
        }

    }

}


class Database{
    
   
    private static $m_pInstance;
    private function __construct() {}
    protected $_config;
    public $error;
    
    
    public function getConnection(){
        
        try {
            $connection = new PDO('mysql:dbname='.$this->getConfig()->database.';host='.$this->getConfig()->host, $this->getConfig()->username, $this->getConfig()->password);
            //$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
            return $connection;
        } catch(PDOException $e) {
            $this->error = $e->getMessage();
        }
            
    }
    
    
    public function save($data){
        
        $connection = $this->getConnection();
        
        if ($connection){
            

            $data = serialize($data);
            $stmt = $connection->prepare("INSERT INTO {$this->getConfig()->table} ({$this->getConfig()->field}) VALUES (:data)");
            
            if (!$stmt){
                $error = $stmt->errorInfo();
                $this->error = $error[2];
                return;
            }
            
            if (!$stmt->execute(array(':data'=>$data))){
                $error = $stmt->errorInfo();
                $this->error = $error[2];
            }
        }
        
    }
    
    
    public function fetchAll(){
        
        
        $connection = $this->getConnection();
        
        if ($connection){      

            $stmt = $connection->prepare("SELECT * FROM {$this->getConfig()->table}");

            if (!$stmt){
                $error = $stmt->errorInfo();
                $this->error = $error[2];
                return;
            }

            if (!$stmt->execute()){
                $error = $stmt->errorInfo();
                $this->error = $error[2];
            }

            $data = array();
            foreach($stmt->fetchAll(PDO::FETCH_ASSOC) AS $row){
                
                $data[] = unserialize($row[$this->getConfig()->field]);
            }
            return $data;
        }
        
        return array();
        
    }


    public function execute(listener $listener){

        $values = $listener->execute();
        if ($listener->success){
            
            // test error
            if (1==0){
                $listener->addError('DB error '.$this->getConfig()->username);
                $listener->success = false;
                return;
            }
            
            // save	
            $this->save($values);
 
            // test error
            if ($this->error){
                $listener->addError('DB error '.$this->error);
                $listener->success = false;
                return;
            }

        }

    }
    
    
    
    public static function getInstance()
    {
        
        if (!self::$m_pInstance){
            self::$m_pInstance = new Database();
        }

        return self::$m_pInstance;
    }
    
    public function setConfig(dbConfig $config){
        $this->_config = $config;
        return $this;
    }
    
    public function getConfig(){
        
        if (!isset($this->_config)){
            $this->setConfig(self::stdConfig());
        }
        
        return $this->_config;
    }
    
    public static function stdConfig($params){
        
        $config = new dbConfig();
        $config->username = isset($params['username']) ? $params['username'] : 'root';
        $config->password = isset($params['password']) ? $params['password'] : '';
        $config->database = isset($params['database']) ? $params['database'] : 'data';
        $config->table = isset($params['table']) ? $params['table'] : 'submissions';
        $config->field = isset($params['field']) ? $params['field'] : 'submitted';
        $config->host = isset($params['host']) ? $params['host'] : 'localhost';
        return $config;
    }
    
}

class dbConfig extends stdClass{}


class Output{
    

    
    public function toXml($data, $startElement = 'root', $xml_version = '1.0', $xml_encoding = 'UTF-8'){
        

        if(!is_array($data)){
           $data = array('response'=>$data);
        }
        $xml = new XmlWriter();
        $xml->openMemory();
        $xml->startDocument($xml_version, $xml_encoding);
        $xml->startElement($startElement);


        function write(XMLWriter $xml, $data){
            foreach($data as $key => $value){
                if(is_array($value)){
                    $xml->startElement($key);
                    write($xml, $value);
                    $xml->endElement();
                    continue;
                }
                $xml->writeElement($key, $value);
            }
        }
        write($xml, $data);
        $xml->endElement();

        
        header ("content-type: text/xml");
        print $xml->outputMemory(true);
    }
    
    
    
    
    public static function toCsv($data = '', $filename=null) {
        
        if(!is_array($data)){
           $data = array('data'=>$data);
        }

        if ($filename===null){
            $filename = date("dMy-H:i:s").".csv";
        }
        
        
        
        $outputBuffer = fopen("php://output", 'w');
        
        // title
        fputcsv($outputBuffer, array_keys(reset($data)));
        
        foreach($data as $val) {
            fputcsv($outputBuffer, $val);
        }
                

        header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename=$filename");
        header("Pragma: no-cache");
        header("Expires: 0");

        fclose($outputBuffer);
    }

    
    public static function toScreen($data = ''){
        
        echo '<pre>';
        var_dump($data);
        echo '</pre>';
        
    }
}
