<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Thick Box demo</title>
	
	<?php // THICKBOX RESOURCES ?>
	<script type="text/javascript" src="thickbox/jquery-latest.js"></script> 
	<script type="text/javascript" src="thickbox/thickbox.js"></script>
	<link rel="stylesheet" href="thickbox/thickbox.css" type="text/css" media="screen" />
	
	<style>
	body { margin:150px; font-size:50px; color:cc0000;}
	</style>
	
	
</head>
	<body>
		click <a href="form.php?height=200&width=400" class="thickbox" title="" style="border:none;">here</a>			
	</body>
</html>