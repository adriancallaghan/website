=== Plugin Name ===
Contributors: codejunkie
Donate link: adriancallaghan.co.uk/clikStats/
Tags: seo, links, log, url, capture, clicks, stats, records, anchor, vistors, counter, retrofit
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 0.6

clikStats is retrofitable pluggin that automatically logs the number of clicks within every post.

== Description ==

clikStats is a plugin that automatically detects the current links within each post.

ClikStats is retrofitable, and requires no special provision from any classes or code.

Once activated, clikStats will compile who, when, what data which can be viewed through the back office.

The beauty of this plugin is in its portability, it can be used straight out of the box, and provide usefull visitor information, without the need to reverse engineer your posts.


== Installation ==

1. unzip the clik_stats.zip file
2. upload the entire unzipped clik_stats folder to the '/wp-content/plugins/' directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Why is the clikStats displaying 'no stats' despite tons of links on the page? =

ClikStats records the results when a vistor clicks a link.
So as soon as vistor has followed a link, clikStats will begin recording statistics for that link.

= Can I contact you with problems or comments ? =

Yes

== Screenshots ==
N/a