<?php 

class test{
	
	function __construct() {
	   }
	
	   	   
	public function index(){
		$this->content->message='Test';
		$this->view='index';
	}
	
	
	
	
}




?>