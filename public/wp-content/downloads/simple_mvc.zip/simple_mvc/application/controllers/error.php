<?php 

class error{
	
	function __construct() {
	   }
	
	   	   
	public function pageNotFound(){
		$this->content->message='Page not found';
		
	}
	
	
	
	
}




?>