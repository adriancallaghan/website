<?php 

class index{
	
	public function __construct() {
		/*
		 * Instaniate the models here
		 * The classes will be loaded from the models directory
		 */
	   }
	
	   	   
	public function index(){
		$this->content->message='Helloworld!';
		$this->content->testArray = array(1,2,3,4,5,6,7,8,9);
		//$this->view='Changed';
	}
	
	
	
	
}




?>