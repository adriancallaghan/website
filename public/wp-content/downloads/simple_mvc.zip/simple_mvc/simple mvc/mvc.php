<?php

/*
 * 
 * Simple MVC 
 * 
 * By Adrian Callaghan 300810
 * 
 */


// enviroment
$env = new stdClass();

// url mapping
$env->url['base'] = dirname($_SERVER['SCRIPT_NAME']);
$env->url['path'] = realpath('.');
$env->url['relative'] = str_replace('//','/',dirname(__FILE__)).'/../application/';
$env->url['request'] = htmlentities($_SERVER['REQUEST_URI']);
$env->url['request_array'] = explode('/',trim($_GET['__url'],'/'));

// mvc
$env->controller = !empty($env->url['request_array'][0]) ? $env->url['request_array'][0] : 'index';
$env->action = !empty($env->url['request_array'][1]) ? $env->url['request_array'][1] : 'index';
$env->view = $env->controller;

// settings
@include_once('mvc_env.php');

// tell the controllers where to load models from
function __autoload($class_name) {
	global $env;
    require_once "{$env->url['relative']}models/$class_name.php";
}


// add custom error controller to list of denys
if (isset($env->error['controller'])){
	$env->routerDeny[] = $env->error['controller'];
}


// mapping
if (isset($env->routerMap) && in_array("{$env->controller},{$env->action}",array_keys($env->routerMap))){
	$route = explode(',',$env->routerMap["{$env->controller},{$env->action}"]);
	$env->controller = $route[0];
	$env->action = $route[1];
	$env->view = $env->controller;
}

// get the controller
if (file_exists("{$env->url['relative']}/controllers/{$env->controller}.php")) {
	require_once("{$env->url['relative']}/controllers/{$env->controller}.php");
	$controller = new $env->controller();	
	} 
	
// unset the controller if this is a denied resource, this is done on URL only, so not to interfere with any mappings
if (isset($env->routerDeny) && in_array(implode(',',$env->url['request_array']),$env->routerDeny)){
	unset($controller, $env->controller);
	}	
	
// if neither the controller or action was found set an error for the error controller to handle
if (!isset($controller) || !method_exists($controller,$env->action)){
	
	// can we run the error handler?
	if (isset($env->error)){
		$env->controller = $env->error['controller'];
		$env->action = $env->error['pageNotFoundAction'];
		$env->view = $env->error['view'];
	
		@require_once("{$env->url['relative']}/controllers/{$env->controller}.php");
		$controller = new $env->controller();	
		if (!method_exists($controller,$env->action)) {
			die("<h1>Fatal error</h1>Missing action: <b>{$env->action}</b> in controller: <b>{$env->controller}</b>");
			}
			
		// output will be handled by the dispatcher below	
		}
	else {
		// if we do not even have an error handler, throw a traditional 404 and die
		ob_start();	?>
		<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
		<html><head><title>404 Not Found</title></head><body>
		<h1>Not Found</h1>
		<p>The requested URL <?php echo $env->url['request']; ?> was not found on this server.</p>
		</body></html>
		<?php header("HTTP/1.0 404 Not Found"); die(ob_get_clean());
	}
}

// dispatcher /////////////////////////////////////////////////

//attempt to execute the action in the controller,
$controller->{$env->action}();	

// check to see if the view has been altered
$env->view = isset($controller->view) ? $controller->view : $env->view;

// set up the content and view
$content = $controller->content;
if (isset($env->prelayout)) foreach ($env->prelayout AS $element) include_once("{$env->url['relative']}/views/$element.phtml");
include_once("{$env->url['relative']}/views/{$env->view}.phtml");
if (isset($env->postlayout)) foreach ($env->postlayout AS $element) include_once("{$env->url['relative']}/views/$element.phtml");





