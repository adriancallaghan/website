<?php 
/*
 * 
 * Simple MVC settings file (this file does not need to be present)
 * Examples of different settings are contained here, just uncomment to use
 * 
 * By Adrian Callaghan 300810
 * 
 */


// error controller
// defines a controller to handle errors, namely the page not found
// the controller is automatically exempt from an actual page request
/*
$env->error['controller']='error';
$env->error['view']='index';
$env->error['pageNotFoundAction']='pageNotFound';
*/



// routerMap
// holds controller and action mappings to different controller, action (comma delimited)
/*
$env->routerMap['foo,bar']='index,index';
*/



// routerDeny
// holds controller and action mappings to deny (comma delimited)
/*
$env->routerDeny[]='controller,action'; // will deny the page /controller/action/
$env->routerDeny[]=''; // will deny homepage
*/



// prelayout
// defines an array of elements to be included before the main view
/*
$env->prelayout = array('header');
*/




// postlayout
// defines an array of elements to be included after the main view
/*
$env->postlayout = array('sidebar','footer');
*/






