Prerequisites
-------------
1.
Windows XP SP 2

2.
JRE/JSDK 1.4.2 or greater

3.
Bluetooth USB dongle

Usage
-----
1.
Use btinstall.exe to install the application to the default directory. The default directory is c:\program files\btscanner


2.
Alternatively, use btinstall with the -f flag to install to product to a directory of your own choice. Firstly you must create a directory, for example:

md c:\pentest

When this directory has been created you can install the product using the following command:

btinstall -f c:\pentest

NB. don't forget to surround your path with double quotes if you have opted to name your directory to include spaces.


3.
If you have accepted the default directory to install your product to you can now move to step 4 and prepare to use the product. If you have chosen to install the product elsewhere then you will have to make a change the following change to the BTConfig.ini file:

ROOTDIR=c:\pentest

This label informs the application of the wherabouts of all the supporting files and must be set to point at the full path name of the user defined installation directory.


4.
An icon will be installed on the desktop for you to run the application. If you prefer not to use the icon to invoke the application, a command line option is available:

java -jar btscanner.jar -c c:\pentest\btscanner\conf\BTConfig.ini


Features
--------
A quick summary of the 10 key features of Bluetooth Scanner for XP:

1. live device discovery.
2. ability to save scan sessions
3. ability to read in saved scan sessions (and then conduct active scans over the top)
4. Probe devices for their service records
5. ability to input user comments related to the device - i.e whether authorized or not, or free flowing comment field.
6. configure the type of service records to be retrieved from device probes.
7. configure the type of service record attributes to be retrieved from device probes.
8. configure the name of the default log file and the default 'saved' scan file.
9. save log information
10. extract device specific information such as:
	OUI (manufacturer)
	dates times when device has been detected
	class of device
	device address
	friendlyname
	whether in range or not. 

Support
-------
Please email any problems, comments or suggestions to support@pentest.co.uk