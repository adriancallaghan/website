<?	
require_once('config.php');	

$dataBase = new DB();
$dataBase->getQuery('SELECT * FROM BOO');

?>