<?php



// database
define ('HOST',		'localhost');
define ('NAME',		'NAME_OF_DATABASE');
define ('USER',		'USER_NAME');
define ('PASS',		'PASSWORD');



// Error messages
define ('ERRS',		false); // Meaningfull error messages on or off (mainly SQL related)
define ('MESSAGE',		'The server encountered an internal error');// Default message
define ('admin_email', 'someone@somewhere.com');// email errors to





// Dynamically load class definitions as required
function __autoload ($class) {
	require_once($class.'.php');
	}

?>