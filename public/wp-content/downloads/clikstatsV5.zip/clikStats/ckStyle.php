<style>
td.noBorder 								{border:none;}
.noBorder a 								{color:#000000;}
.tableContents a							{color:#000000;}
.noBorder a:hover							{color:#cc0000;}
.tableContents a:hover						{color:#cc0000;}
</style>